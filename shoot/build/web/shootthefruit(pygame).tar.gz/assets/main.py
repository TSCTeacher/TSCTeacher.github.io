import pygame
import asyncio
import objects
from constants import WINDOW_WIDTH, WINDOW_HEIGHT, BG_COLOR

# Initialize Pygame
pygame.init()

# Set up the game window
window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SCALED)

# Initialize game parameters
clock = pygame.time.Clock()
running = True

fruit = objects.Fruit()
all_sprites = pygame.sprite.Group()
all_sprites.add(fruit)

all_sprites.draw(window)

async def main():
    global running, fruit

    while running:
        # Stop the game if QUIT event is fired
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if fruit.CheckClicked(event.pos):
                    window.fill(BG_COLOR)
                    fruit = objects.Fruit()
                    all_sprites.add(fruit)
                    all_sprites.draw(window)

        # Update display
        pygame.display.flip()
        await asyncio.sleep(0)

asyncio.run(main())
