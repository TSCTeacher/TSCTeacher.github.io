import pygame
import random
from constants import WINDOW_HEIGHT, WINDOW_WIDTH

class Fruit(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()

        rng = random.randint(1, 3)

        if rng == 1:
            self.image = pygame.image.load("images/apple.png")
        elif rng == 2:
            self.image = pygame.image.load("images/orange.png")
        else:
            self.image = pygame.image.load("images/pineapple.png")

        self.rect = self.image.get_rect()
        self.rect.centerx = random.randint(20, WINDOW_WIDTH - 20) #self.rect.centerx = WINDOW_WIDTH // 2
        self.rect.centery = random.randint(20, WINDOW_HEIGHT - 20) #self.rect.centery = WINDOW_HEIGHT // 2

    def CheckClicked(self, mouse):
        if self.rect.collidepoint(mouse):
            self.kill()
            print("Click")
            return True

        return False
