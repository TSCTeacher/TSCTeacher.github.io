import pgzrun
import os
import random
import asyncio

# Dimensions of screen
WIDTH = 960
HEIGHT = 720

# Constant Varibales
GRAVITY = 0.2
JUMP_POWER = -5
FLOOR = 530

# Game Parameters
game_started = False
score = 0
scored = False
game_over = True
on_floor = False

# SFXs
wing_sound = sounds.sfx_wing
hit_sound = sounds.sfx_hit
point_sound = sounds.sfx_point
die_sound = sounds.sfx_die

#Center Window
os.environ["SDL_VIDEO_CENTERED"] = "1"

# Bird Actor
bird = Actor("birdup")
bird.pos = (WIDTH//2, HEIGHT//2)
bird.vy = 0

# Grass Actor
grass = Actor("ground")
grass.pos = (WIDTH//2, HEIGHT)

pipe_speed = 0

#Text Properties
game_over_text_y = HEIGHT//2 - 100
game_over_alpha = 0

score_text_y = HEIGHT//2 + 100
score_alpha = 0

# Spawn in Pipes
def spawn_pipes():
    # Set global variables
    global top_pipe, bottom_pipe, pipe_speed
    GREEN_PIPE_SPEED = 5
    RED_PIPE_SPEED = 10

    rng = random.randint(1, 2)
    if rng == 1:
        # Pipe Actors
        bottom_pipe = Actor("greenbotpipe")
        top_pipe = Actor("greentoppipe")
        pipe_speed = GREEN_PIPE_SPEED
    else:
        # Pipe Actors
        bottom_pipe = Actor("redbotpipe")
        top_pipe = Actor("redtoppipe")
        pipe_speed = RED_PIPE_SPEED

    bottom_pipe.pos = (WIDTH-100, 550)
    top_pipe.pos = (WIDTH-100, -50)

# Animate
def animate():
    if bird.image == "birdup":
        bird.image = "birdside"
    elif bird.image == "birdside":
        bird.image = "birddown"
    else:
        bird.image = "birdup"

def death_animation():
    bird.angle = -90
    die_sound.play()

def reset_angle():
    bird.angle = 0

def draw_screen():
    if game_over == False:
        screen.fill("lightblue")
        screen.draw.filled_circle((WIDTH-100, 100), 50, "yellow")
        top_pipe.draw()
        bottom_pipe.draw()
        grass.draw()
        bird.draw()
    else:
        screen.fill("lightblue")
        screen.draw.filled_circle((WIDTH-100, 100), 50, "yellow")
        grass.draw()
        bird.draw()

spawn_pipes()

def draw():
    if not game_over:
        draw_screen()

        screen.draw.text(str(score), color="white", fontname="bird", fontsize=80, midtop=(WIDTH//2, 30))
    else:
        draw_screen()
        screen.draw.text("GAME OVER", color="white", owidth=1.5, ocolor="white", fontname="bird", fontsize=80, center=(WIDTH//2, game_over_text_y), alpha=game_over_alpha)
        screen.draw.text("GAME OVER", color="orange", owidth=0.5, ocolor="black", fontname="bird", fontsize=80, center=(WIDTH//2, game_over_text_y), alpha=game_over_alpha)

        screen.draw.text("Score: " + str(score), color="white", owidth=0.5, ocolor="black", fontname="bird", fontsize=80, center=(WIDTH//2, score_text_y))

async def update():
    global score, scored, game_over, on_floor, game_over_text_y, game_over_alpha, score_text_y

    bird.angle = bird.angle

    if game_started and not game_over:
        top_pipe.x -= pipe_speed
        bottom_pipe.x -= pipe_speed

        # Set Gravity and Jump
        bird.vy += GRAVITY
        bird.y += bird.vy

        # Check for bird collision
        if bird.colliderect(top_pipe) or bird.colliderect(bottom_pipe) or bird.colliderect(grass):
            hit_sound.play()
            clock.unschedule(animate)
            clock.schedule(death_animation, 0.5)
            game_over = True

        # Check if scored
        if top_pipe.x < bird.x and bottom_pipe.x < bird.x and not scored:
            # increase score
            point_sound.play()
            scored = True
            score += 1

        # Spawn new pipes once the old ones leave the screen
        if top_pipe.x < -50 and bottom_pipe.x < -50:
            # spawn new set of pipes
            spawn_pipes()

            # set scored back to False
            scored = False

            # put pipes back on right side of screen
            top_pipe.x = WIDTH + 50
            bottom_pipe.x = WIDTH + 50

    if bird.y > FLOOR and bird.colliderect(grass):
        on_floor = True

    if game_over and not on_floor:
        # Set Gravity
        bird.vy += GRAVITY
        bird.y += bird.vy

    if game_over and game_over_text_y != HEIGHT//2 - 50:
        game_over_text_y += 5

    if game_over and game_over_alpha != 1:
        game_over_alpha += 0.1

    if game_over and score_text_y != HEIGHT//2 + 50:
        score_text_y -= 5

    await asyncio.sleep(0)

# Space bar configuration
def on_key_down(key):
    if game_started and not game_over:
        if key == keys.SPACE or key == keys.W or key == keys.UP:
            wing_sound.play()
            bird.angle = 45
            clock.schedule(reset_angle, 0.5)
            bird.vy = JUMP_POWER

# Start Game
def on_mouse_down():
    global game_started
    game_started = True
    clock.unschedule(animate)
    clock.schedule_interval(animate, .1)

clock.schedule_interval(animate, .5)

pgzrun.go()


