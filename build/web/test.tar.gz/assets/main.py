import pygame
import asyncio


pygame.init()

import pygame

pygame.init()
screen = pygame.display.set_mode((320, 240))
pygame.display.set_caption("Async Pygbag Test")
clock = pygame.time.Clock()

async def main():
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        screen.fill((0, 0, 0))
        pygame.display.update()
        
        # Crucial for browser compatibility and avoiding freezes
        await asyncio.sleep(0)
        clock.tick(60)

# Start the async runtime
asyncio.run(main())